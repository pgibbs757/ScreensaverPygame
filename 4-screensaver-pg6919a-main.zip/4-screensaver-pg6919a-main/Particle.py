import random

import loc
import pygame
import self
from pygame import MOUSEMOTION, MOUSEBUTTONUP, MOUSEBUTTONDOWN


# Draws a circle that falls from wherever it is created.
# Can be given an initial speed in any direction.
# Each frame the y speed will slowly shift by the GRAVITY amount
class SimpleButton():
    STATE_IDLE = 'idle'  # button is up, mouse not over button
    STATE_ARMED = 'armed'  # button is down, mouse over button
    STATE_DISARMED = 'disarmed'  # click down on button, rolled off

    def __init__(self, window, loc, up, down): # saves all values passed in into instance variables.
        self.window = window
        self.loc = loc
        self.surfaceUp = pygame.image.load(up)
        self.surfaceDown = pygame.image.load(down)

        # Get rect of button to check if mouse is over the button
        self.rect = self.surfaceUp.get_rect()
        self.rect[0] = loc[0]
        self.rect[1] = loc[1]

        self.state = SimpleButton.STATE_IDLE

# whenever main program detects any event it calls handleEvent() method.
    def handleEvent(self, eventObj):
        # Will return True is user clicks button but normally returns False.
        # Checks if the event TYPE is MOUSEMOTION, MOUSEBUTTONUP, MOUSEBUTTONDOWN
        if eventObj.type not in (MOUSEMOTION, MOUSEBUTTONUP, MOUSEBUTTONDOWN):
            return False

        eventPointInButtonRect = self.rect.collidepoint(eventObj.pos)
        # self.state is used to detect if user clicked button.
        # The handleEvent() method returns True when the user completes a mouse click by
        # pressing down on the button but then releasing the same button. For other cases handleEvent() returns False.
        if self.state == SimpleButton.STATE_IDLE:
            if (eventObj.type == MOUSEBUTTONDOWN) and eventPointInButtonRect:
                self.state = SimpleButton.STATE_ARMED

        elif self.state == SimpleButton.STATE_ARMED:
            if (eventObj.type == MOUSEBUTTONUP) and eventPointInButtonRect:
                self.state = SimpleButton.STATE_IDLE
                return True  # clicked!

            if (eventObj.type == MOUSEMOTION) and (not eventPointInButtonRect):
                self.state = SimpleButton.STATE_DISARMED

        elif self.state == SimpleButton.STATE_DISARMED:
            if eventPointInButtonRect:
                self.state = SimpleButton.STATE_ARMED
            elif eventObj.type == MOUSEBUTTONUP:
                self.state = SimpleButton.STATE_IDLE

        return False

    def draw(self): # The draw method use the state of the object's instance self.state to decide which image to draw
        # Draw the button's current appearance to the window
        if self.state == SimpleButton.STATE_ARMED:
            self.window.blit(self.surfaceDown, self.loc)

        else:  # IDLE or DISARMED
            self.window.blit(self.surfaceUp, self.loc)

class Particle:
    GRAVITY = 0.1  # changes the rate that particles move towards bottom of screen
    WEIGHT_MAX = 20  # affects size and wind resistance

    def __init__(self, window: pygame.surface, windowWidth: int, windowHeight: int, loc: tuple, speed: tuple,
                 color: tuple = (255, 255, 255), weight=None):
        self.window = window  # remember the window, so we can draw later
        self.windowWidth = windowWidth
        self.windowHeight = windowHeight
        if weight is None:
            self.weight = random.randrange(1, Particle.WEIGHT_MAX + 1)
        else:
            self.weight = weight

        self.x = loc[0]
        self.y = loc[1]
        self.speedX = speed[0]
        self.speedY = speed[1]

        self.dead = False
        self.color = color
        self.r = color[0]
        self.g = color[1]
        self.b = color[2]

    def update(self):
        self.speedY += Particle.GRAVITY
        self.x += self.speedX
        self.y += self.speedY

        if self.y > self.windowHeight:
            self.dead = True

    def draw(self):
        pygame.draw.circle(self.window, (self.r, self.g, self.b), (self.x, self.y), self.weight, 0)
