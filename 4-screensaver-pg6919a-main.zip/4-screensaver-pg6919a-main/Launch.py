# pygame demo 0 - window only
import pygame
import sys
import random
import pygwidgets
from Particle import SimpleButton

# Define constants
BLACK = (0, 0, 0)
WINDOW_WIDTH = 1440
WINDOW_HEIGHT = 845
FRAMES_PER_SECOND = 30
UFO_WIDTH_HEIGHT = 120
FIREBALL_WIDTH_HEIGHT = 5
MAX_WIDTH = WINDOW_WIDTH - UFO_WIDTH_HEIGHT
MAX_HEIGHT = WINDOW_HEIGHT - UFO_WIDTH_HEIGHT
MAX_HEIGHTF = WINDOW_WIDTH - FIREBALL_WIDTH_HEIGHT
MAX_WIDTHF = WINDOW_WIDTH - FIREBALL_WIDTH_HEIGHT
TARGET_X = 550
TARGET_Y = 470
TARGET_WIDTH_HEIGHT = 120
N_PIXELS_TO_MOVE = 10
FIREBALL_SPEED = 10  # Adjust the fireball falling speed

# Initialize the world
pygame.init()
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

clock = pygame.time.Clock()

# Load assets
ufoImage = pygame.image.load('images/ufo-2.png')
fireballImage = pygame.image.load('images/fire ball-2.png')
targetImage = pygame.image.load('images/target.svg')
pygame.mixer.music.load('sounds/Future Islands - Tin Man.mp3')
pygame.mixer.music.play(-1, 1.5)

# Initialize variables
oButtonA = SimpleButton(window, (550, 75), 'images/whitebuttonup.png', 'images/whitebuttondown-3.png')
oButtonB = SimpleButton(window, (720, 75), 'images/whitebuttonup.png', 'images/whitebuttondown-3.png')
oTextField = pygwidgets.DisplayText(window, (425, 10), value='WELCOME TO SPACE JAM', fontSize=40,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(255, 255, 255))
oTextField2 = pygwidgets.DisplayText(window, (425, 55), value='Try not to get hit by the fireballs!', fontSize=20,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(255, 255, 255))
oTextField3 = pygwidgets.DisplayText(window, (-200, 400), value='', fontSize=35,
                                    fontName='Comic Sans MS', width=2000, justified='center', textColor=(255, 0, 0))
oTextField4 = pygwidgets.DisplayText(window, (900, 40), value='Use the Arrow keys to control the UFO!', fontSize=20,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(255, 255, 255))
oTextField5 = pygwidgets.DisplayText(window, (-50, 40), value='Use the Arrow keys to control the UFO!', fontSize=20,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(255, 255, 255))
oTextField6 = pygwidgets.DisplayText(window, (350, 95), value='START', fontSize=20,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(0, 0, 0))
oTextField7 = pygwidgets.DisplayText(window, (520, 95), value='STOP', fontSize=20,
                                    fontName='Comic Sans MS', width=550, justified='center', textColor=(0, 0, 0))


ufoX = random.randrange(MAX_WIDTH)
ufoY = random.randrange(MAX_HEIGHT)
targetRect = pygame.Rect(TARGET_X, TARGET_Y, TARGET_WIDTH_HEIGHT, TARGET_WIDTH_HEIGHT)

game_started = False
fireballs = []

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if oButtonA.handleEvent(event):
            game_started = True
            oTextField3.setValue('')
        if oButtonB.handleEvent(event):
            game_started = False

    keyPressedTuple = pygame.key.get_pressed()

    if game_started:
        if keyPressedTuple[pygame.K_LEFT]:
            ufoX = ufoX - N_PIXELS_TO_MOVE
        if keyPressedTuple[pygame.K_RIGHT]:
            ufoX = ufoX + N_PIXELS_TO_MOVE
        if keyPressedTuple[pygame.K_UP]:
            ufoY = ufoY - N_PIXELS_TO_MOVE
        if keyPressedTuple[pygame.K_DOWN]:
            ufoY = ufoY + N_PIXELS_TO_MOVE

        # Generate new fireball
        if random.random() < 0.05:  # Adjust the probability of fireball creation
            fireballX = random.randrange(WINDOW_WIDTH - FIREBALL_WIDTH_HEIGHT)
            fireballY = 0
            fireballs.append((fireballX, fireballY))

    # Update fireball positions
    for i in range(len(fireballs)):
        fireballX, fireballY = fireballs[i]
        fireballY += FIREBALL_SPEED
        fireballs[i] = (fireballX, fireballY)

    # Check for collisions between fireballs and UFO
    for i in range(len(fireballs)):
        fireballX, fireballY = fireballs[i]
        fireballRect = pygame.Rect(fireballX, fireballY, FIREBALL_WIDTH_HEIGHT, FIREBALL_WIDTH_HEIGHT)
        if fireballRect.colliderect(ufoX, ufoY, UFO_WIDTH_HEIGHT, UFO_WIDTH_HEIGHT):
            game_started = False
            oTextField3.setValue('You got hit by a fireball. You died. Click Start to try again!')

    window.fill(BLACK)
    oButtonA.draw()
    oButtonB.draw()
    oTextField.draw()
    oTextField2.draw()
    oTextField4.draw()
    oTextField5.draw()
    oTextField6.draw()
    oTextField7.draw()

    window.blit(targetImage, (TARGET_X, TARGET_Y))
    for fireballX, fireballY in fireballs:
        window.blit(fireballImage, (fireballX, fireballY))
    window.blit(ufoImage, (ufoX, ufoY))
    oTextField3.draw()

    pygame.display.update()
    clock.tick(FRAMES_PER_SECOND)